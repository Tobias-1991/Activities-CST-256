<?php
namespace App\Services\Data;

class Database
{
    
    private $servername;
    private $username;
    private $password;
    private $dbName;
    
    public function __construct() {
        
        $this->servername = "localhost";
        $this->username = "root";
        $this->password = "root";
        $this->dbName = "activity2";
        
    }
    public function getConn()
    {
        $conn = mysqli_connect($this->servername, 
            $this->username, $this->password, $this->dbName);
        if($conn == false) {
            die("ERROR: Connection failed: " . mysqli_connect_error());
        }
        return $conn;
    }
}

