<?php
namespace App\Services\Data;

class OrderDAO
{
    public function addOrder($product) {
        $data = new Database();
        $link = $data->getConn();
        if(is_null($link))
        {
            echo "NOTHING IS HERE";
        }
        else
        {
            echo "Something is here!";
        }
        $sql = $link->prepare("INSERT INTO order (product, customer_id) VALUES (?, ?)");
        $sql->bind_param("si", "testing", 3);
        $sql->execute();
        //$sql = "INSERT INTO order (product, customer_id) VALUES ('testing', 1)";
        //$results = mysqli_query($link, $sql);
        if($sql->affected_rows > 0) {
            
            //echo " Welcome to the website!";
            //echo '/loginpassed';
            echo "success";
            return true;
        } else {
            echo 'failed';
            return false;
        }
    }
    
}

