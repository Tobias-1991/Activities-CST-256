<?php
namespace App\Services\Data;

// use 'UserModels.php';
use App\Models\UserModels;
class SecurityDAO 
{

    public function findByUser(UserModels $user)
    {
        
        //echo "testing";
        echo $user->getUsername();
        echo $user->getPassword();
        $request1 = $user->getUsername();
        $request2 = $user->getPassword();
        $this->validateform($request1);
        $this->validateform($request2);
        $conn = new Database();
        $link = $conn->getConn();
        $username = $user->getUsername();
        $password = $user->getPassword();
        $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
        $results = mysqli_query($link, $sql);
        if(mysqli_num_rows($results)==1) {
            
            //echo " Welcome to the website!";
            //echo '/loginpassed';
            return true;
        } else {
            //echo '/loginfailed';
            return false;
        }
    }
}

