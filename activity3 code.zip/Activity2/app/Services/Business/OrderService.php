<?php
namespace App\Services\Business;

class OrderService
{
    
    public function createOrder($firstName, $lastName, $product) {
        
    }
}

