<?php
namespace App\Services\Business;

use App\Models\UserModels;
use App\Services\Data\SecurityDAO;

class SecurityService
{
    public function Login(UserModels $usermodel ) {

        if (SecurityDAO.findByUser()) {
   return true;
        }
        else {
            return false;
        }
    
    
}

}