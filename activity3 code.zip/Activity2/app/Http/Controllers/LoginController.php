<?php

namespace App\Http\Controllers;
use App\Models\UserModels;
use App\Services\Data\SecurityDAO;
use Illuminate\Http\Request;
use App\Services\Data\OrderDAO;
class LoginController extends Controller
{
    public function index(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');
        $this->validateForm($request);
        $user = new UserModels($username, $password);
        
        $order = new OrderDAO();
        
        $order->addOrder('Test');
        exit;
        
       // echo $user->getUsername();
       // echo $user->getPassword();
        //echo "I hope this works";
        $service = new SecurityDAO();
        
        if($service->findByUser($user)) {
            return view('loginPassed2');
        } else {
            return view('loginfailed');
        }
//        
        
    }
    private function validateForm(Request $request) {
        $rules = ['username' => 'Required | Between:4,10 | 
        Alpha', 'password' => 'Required | Between:4,10'];
        
        $this->validate($request, $rules);
    }
    //
}
