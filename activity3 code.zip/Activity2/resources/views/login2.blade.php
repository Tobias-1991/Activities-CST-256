
<div align="center">
@extends('layouts.appmaster')
@section('title', 'Login Page')

@include('layouts.header')
    
        @yield('content')
        <form action = "dologin" method = "post">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
		<table>
			<tr>
				<td>Username: </td>
				<td><input type = "text" name = "username" /></td>
				<?php echo $errors->first('username')?>
			</tr>

			<tr>
				<td>Password:</td>
				<td><input type = "password" name = "password" /></td>
				<?php echo $errors->first('password')?>
			</tr>
			<tr>
				<td colspan = "2" align = "center">
					<input type = "submit" value = "Submit" />
				</td>
		</table></form>
        @section('content')
    
@endsection
    
    @include('layouts.footer')
    </div>



		