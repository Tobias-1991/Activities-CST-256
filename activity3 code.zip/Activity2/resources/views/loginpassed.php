<?php
echo "You passed the test!";